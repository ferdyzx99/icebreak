package com.example.ma.miviewpager;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
//fernando

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //aca armo los datos
        List<TipoPantalla> datosFragment = new ArrayList<>();

        datosFragment.add(new TipoPantalla("Algoritmo Standard",0xFFFF3300));
        datosFragment.add(new TipoPantalla("Algoritmo reforzado",0xFFFFFF00));
        datosFragment.add(new TipoPantalla("Algoritmo Análisis profundo",0xFF99FF33));



        //hago el maldito Handle del viewpager
        ViewPager miViewPager = (ViewPager) findViewById(R.id.MiViewPager);

        //instancio el adapter que hice
        AdapterIceBreakviewPager adapterdelViewPager = new AdapterIceBreakviewPager(getSupportFragmentManager(),datosFragment);



        //ahora agarro el viewpager, o sea el handle del viewpager, y lo linkeio con el adapter

        miViewPager.setAdapter(adapterdelViewPager);

        //seteo cuestiones esteticas
      //  miViewPager.setClipToPadding(false);
        miViewPager.setPageMargin(10);

    }
}
