package com.example.ma.miviewpager;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ma on 02/11/17.
 */

public class AdapterIceBreakviewPager extends FragmentStatePagerAdapter {

List<Fragment>  milistadefragments;


    public AdapterIceBreakviewPager(FragmentManager fm, List<TipoPantalla> misparametros) {
        super(fm);
        milistadefragments = new ArrayList<>();

        milistadefragments.add( IceBreakFragment.fabricadordeFragments(misparametros.get(0)) );
        milistadefragments.add( IceBreakFragment.fabricadordeFragments(misparametros.get(1)) );
        milistadefragments.add( IceBreakFragment.fabricadordeFragments(misparametros.get(2)) );
    }

    @Override
    public Fragment getItem(int position) {
        return milistadefragments.get(position);
    }

    @Override
    public int getCount() {
        return milistadefragments.size();
    }
}
