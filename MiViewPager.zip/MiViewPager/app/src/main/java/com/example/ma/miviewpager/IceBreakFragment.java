package com.example.ma.miviewpager;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class IceBreakFragment extends Fragment {


    //los datos que va a recibir mi fabrica van en el constructo (o sea, las pilas del autito)
    public static final String ObjetoConLaConfiguracion = "ObjetoConLaConfiguracion";

    public IceBreakFragment() {
        // Required empty public constructor
    }


    //esta es la fabriquita de fragment, o sea pone en el paquete las pilas del autito
    public static IceBreakFragment fabricadordeFragments(TipoPantalla ptipoPantalla){

        IceBreakFragment fragmentBuffer = new IceBreakFragment();
        //tengo que setear el bundle porque la mierda de android no maneja bien las cosas si se lo mando en un parametro
        //agrego el pack de pilas al autito
        Bundle bundle = new Bundle();
        bundle.putSerializable(ObjetoConLaConfiguracion,ptipoPantalla);
        fragmentBuffer.setArguments(bundle);





        return fragmentBuffer;
    }


//aca, el usuario abrio el paquete y le tiene que poner las pilas al autito
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ice_break, container, false);

        Bundle bundle = getArguments();
        TipoPantalla pObjetoConLaConfiguracion = (TipoPantalla) bundle.getSerializable(ObjetoConLaConfiguracion);
        //Ahora seteo el textview

        //hago el handle del set text, notar que findviewbyid es un metodo de view
        TextView tvTitulo = (TextView) view.findViewById(R.id.titulo);
        tvTitulo.setText(pObjetoConLaConfiguracion.getTitulo());
        view.setBackgroundColor(pObjetoConLaConfiguracion.getColor());

        return view;
    }

}
