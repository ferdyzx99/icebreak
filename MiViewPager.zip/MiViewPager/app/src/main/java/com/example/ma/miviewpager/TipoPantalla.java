package com.example.ma.miviewpager;

import java.io.Serializable;

/**
 * Created by ma on 02/11/17.
 */

public class TipoPantalla implements Serializable {

private String Titulo;
private Integer tiempo;
private Integer color;

    public TipoPantalla(String titulo) {
        Titulo = titulo;
    }

    public TipoPantalla(String titulo, Integer color) {
        Titulo = titulo;
        this.color = color;
    }

    public String getTitulo() {
        return Titulo;
    }

    public Integer getTiempo() {
        return tiempo;
    }

    public Integer getColor() {
        return color;
    }


    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public void setTiempo(Integer tiempo) {
        this.tiempo = tiempo;
    }

    public void setColor(Integer color) {
        this.color = color;
    }
}
