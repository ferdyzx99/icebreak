package com.example.andres.viewpager;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by andres on 29/05/17.
 */

public class AdapterViewPager extends FragmentStatePagerAdapter{

    List<Fragment> fragments;

    public AdapterViewPager(FragmentManager fm, List<Integer> colores) {
        super(fm);
        fragments = new ArrayList<>();
        for(Integer color : colores){
            fragments.add(FragmentColor.creadorDeFragmentColor(color));
        }
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}
